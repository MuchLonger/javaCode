package MyGame.MyGameCode;

/**
 * @description: 用来保存一些常量
 * @Time: 2018/8/7 16:05
 */
public class Constant {
    /* 窗口的宽高 */
    public static final int GAME_WIDTH=500;
    public static final int GAME_HEIGHT=500;
    public static final int SPEED=3;
}
